<?php 

class Third_Ys_Configsdk {
    //
    //命令码
    const CONFIG_CMDCODE = 192;   //0xC0
    
    ///////////////////////// 编码 ///////////////////////////
    
    public static function encodeConfigMsg($msgJsonObj, &$msgLen) {
        
        $cmdCode = $msgJsonObj->cmdCode;
        $objType = $msgJsonObj->objType;
        $objID = $msgJsonObj->objID;
        $msgSign = $msgJsonObj->sign;
        $msgSignBin = pack("n", $msgSign);
        $propRegion;
        $packBin;
        
        switch ($cmdCode) {
            case self::CONFIG_CMDCODE:
                echo "\n---------- read all config -----------\n";
                $packBin = Third_Ys_Helpersdk::readConfigEncode($msgJsonObj, $msgLen);
                
                return $packBin;
            case 255:
                $packBin = "fefefe7e0034".$msgSignBin."0000800000DF000001005E27605C6D736D7A707E793860727930567A797B887E847E394A50533D7B447D137f";
                
                return $packBin;
        }
    }
    
    /**
     * 解码所有配置信息
     * @param unknown $msgBin
     * @param unknown $msgCRC
     * @return array
     */
    public static function decodeConfigMsg($msgBin, &$msgCRC, $typeMap) {
        
        $dataArray;
        $cmdFormat = "@13/C1cmdCode";
        $cmdArr = unpack($cmdFormat, $msgBin);
        $cmdCode = $cmdArr["cmdCode"];
        
        switch ($cmdCode) {
            case self::CONFIG_CMDCODE:
                $cmdArr = Third_Ys_Helpersdk::readConfigDecode($msgBin, $msgCRC, $typeMap);
                break;
        }
        
        return array('data'=>$cmdArr);
    }
    
}