<?php
//分组类
class Third_Ys_Groupsdk {

    const CREATE_GROUP_CMDCODE = 1;
    const DELETE_GROUP_CMDCODE = 2;
    const MODIFY_GROUP_CMDCODE = 3;
    const UPDATE_GROUP_CMDCODE = 4;
    const REMOTE_CONTROL_GROUP_CMDCODE = 16;
    const READ_GROUP_CONFIG = 192;
    const LIST_OBJID_CMDCODE = 195;     //列表同类对象ID
    
    private static function createGroupEncode($msgJsonObj, &$msgLen) {
        echo "\n --- create group ------- \n";
        
        $cmdCode = $msgJsonObj->cmdCode;
        $objType = $msgJsonObj->objType;
        
        $groupName = $msgJsonObj->data->name;
        $devArr = $msgJsonObj->data->devArr;
        
        $devNum = count($devArr);
        
        $propRegion = 0x8000;
        $propRegionBin = pack("n", $propRegion);
        $objTypeBin = pack("C", $objType);
        $cmdCodeBin = pack("C", $cmdCode);
        $objIDBin = pack("n",$msgJsonObj->objID);
        $fixLenBin = pack("n",28);
        $extLenBin = pack("n", 2*$devNum);
        
        $nameUnicode = Third_Ys_Helpersdk::unicode_encode($groupName);
        $nameBin = Third_Ys_Helpersdk::unicode_tobin($nameUnicode);
        
        $reserved4B = pack("a4", 0);
        $devNumBin = pack("n", $devNum);
        $reserved6B = pack("a6", 0);
        
        $packBin = $propRegionBin.$objTypeBin.$cmdCodeBin.$objIDBin.$fixLenBin.$extLenBin
            .$nameBin.$reserved4B.$devNumBin.$reserved6B;
        for ($i = 0; $i < $devNum; $i++) {
            $devIDTemp = pack("n", $devArr[$i]);
            $packBin .= $devIDTemp;
        }
        
        $msgLen = 18 + 32 + 2*$devNum;
        
        return $packBin;
    }
    
    private static function deleteGroupEncode($msgJsonObj, &$msgLen) {
        echo "\n --- delete group ------- \n";
        
        $cmdCode = $msgJsonObj->cmdCode;
        $objType = $msgJsonObj->objType;
        
        $propRegion = 0x8000;
        $propRegionBin = pack("n", $propRegion);
        $objTypeBin = pack("C", $objType);
        $cmdCodeBin = pack("C", $cmdCode);
        $objIDBin = pack("n",$msgJsonObj->objID);
        
        $packBin = $propRegionBin.$objTypeBin.$cmdCodeBin.$objIDBin;
        
        $msgLen = 18;
        
        return $packBin;
    }
    
    private static function updateGroupEncode($msgJsonObj, &$msgLen) {
        echo "\n --- update group ------- \n";
        
        $cmdCode = $msgJsonObj->cmdCode;
        $objType = $msgJsonObj->objType;
        $name = $msgJsonObj->name;
        
        $propRegion = 0x8000;
        $propRegionBin = pack("n", $propRegion);
        $objTypeBin = pack("C", $objType);
        $cmdCodeBin = pack("C", $cmdCode);
        $objIDBin = pack("n",$msgJsonObj->objID);
        
        $nameUnicode = Third_Ys_Helpersdk::unicode_encode($name);
        $nameBin = Third_Ys_Helpersdk::unicode_tobin($nameUnicode);
//         $nameBin = "";
//         $nameArr = str_split($nameUnicode,2);
//         $nameArrLen = count($nameArr);
//         for ($i = 0; $i < 16; $i++) {
//             $chaTemp="";
//             if ($i < $nameArrLen) {
//                 $chaTemp = $nameArr[$i];
//                 $chaTemp = hexdec($chaTemp);
//             } else {
//                 $chaTemp = 0x00;
//             }
//             $nameBin .= pack("C", $chaTemp);
//         }
//         $nameUnicodeBin = pack("C16", $nameUnicode);
        
        $packBin = $propRegionBin.$objTypeBin.$cmdCodeBin.$objIDBin.$nameBin;
        
        $msgLen = 18+16;
        
        return $packBin;
    }
    
    private static function controlGroupEncode($msgJsonObj, &$msgLen) {
        echo "\n --- remote control group ------- \n";
        
        $cmdCode = $msgJsonObj->cmdCode;
        $objType = $msgJsonObj->objType;
        
        $targetType = $msgJsonObj->data->targetType; //目标站点类别
        $subCmdArr = $msgJsonObj->data->subCmdArr;
        
        $subCmdArrLen = count($subCmdArr);
        
        $propRegion = 0x8000;
        $propRegionBin = pack("n", $propRegion);
        $objTypeBin = pack("C", $objType);
        $cmdCodeBin = pack("C", $cmdCode);
        $objIDBin = pack("n",$msgJsonObj->objID);
        $targetTypeBin = pack("C",$targetType);
        $reserved1B = pack("C", 0);
        $subCmdArrLenBin = pack("n", $subCmdArrLen);
        
        $packBinTemp = Third_Ys_Devicesdk::encodeSubCmdArr($subCmdArr);
        
        $packBin = $propRegionBin.$objTypeBin.$cmdCodeBin.$objIDBin.$targetTypeBin.$reserved1B
            .$subCmdArrLenBin.$packBinTemp;
        
        $msgLen = 18 + 4 + 4*$subCmdArrLen;
        
        return $packBin;
    }
    
    public static function encodeGroupMsg($msgJsonObj, &$msgLen) {
        
        $cmdCode = $msgJsonObj->cmdCode;
        $propRegion;
        $packBin;
        
        switch ($cmdCode) {
            case self::REMOTE_CONTROL_GROUP_CMDCODE:
                //遥控组
                $packBin = self::controlGroupEncode($msgJsonObj, $msgLen);
                break;
            case self::CREATE_GROUP_CMDCODE:
            case self::MODIFY_GROUP_CMDCODE:
                
                $packBin = self::createGroupEncode($msgJsonObj, $msgLen);
                break;
            case self::DELETE_GROUP_CMDCODE:
                $packBin = self::deleteGroupEncode($msgJsonObj, $msgLen);
                break;
            case self::UPDATE_GROUP_CMDCODE:
                $packBin = self::updateGroupEncode($msgJsonObj, $msgLen);
                break;
            case self::READ_GROUP_CONFIG:
                echo "\n ------------ read group configs -----------\n";
                $packBin = Third_Ys_Helpersdk::readConfigEncode($msgJsonObj, $msgLen);
                break;
            case self::LIST_OBJID_CMDCODE:
                $packBin = Third_Ys_Helpersdk::listAllObjIDs($msgJsonObj, $msgLen);
                
                break;
        }
        
        return $packBin;
        
    }
    
    //////////////////// 解码 ////////////////////
    
    public static function decodeGroupMsg($msgBin, &$msgCRC, $typeMap) {
        
        $dataArray;
        $cmdFormat = "@13/C1cmdCode";
        $cmdArr = unpack($cmdFormat, $msgBin);
        $cmdCode = $cmdArr["cmdCode"];
        
        switch ($cmdCode) {
            case self::REMOTE_CONTROL_GROUP_CMDCODE:
                $cmdArr = Third_Ys_Helpersdk::decodeCommonErrorMsg($msgBin, $msgCRC);
                break;
            case self::CREATE_GROUP_CMDCODE:
                $cmdArr = self::createGroupDecode($msgBin, $msgCRC);
                break;
            case self::MODIFY_GROUP_CMDCODE:
                $cmdArr = Third_Ys_Helpersdk::decodeCommonErrorMsg($msgBin, $msgCRC);
                break;
            case self::DELETE_GROUP_CMDCODE:
                $cmdArr = Third_Ys_Helpersdk::decodeCommonErrorMsg($msgBin, $msgCRC);
                break;
            case self::UPDATE_GROUP_CMDCODE:
                $cmdArr = Third_Ys_Helpersdk::decodeCommonErrorMsg($msgBin, $msgCRC);
                break;
            case self::READ_GROUP_CONFIG:
                $cmdArr = Third_Ys_Helpersdk::readConfigDecode($msgBin, $msgCRC, $typeMap);
                break;
            case self::LIST_OBJID_CMDCODE:
                $cmdArr = Third_Ys_Helpersdk::listAllObjIDsDecode($msgBin, $msgCRC);
                break;
        }
        
        return array('data'=>$cmdArr);
        
    }
    
    private static function createGroupDecode($msgBin, &$msgCRC) {
        
        echo "\n --- create group decode ------- \n";
        
        $cmdFormat = "@16/n1cmdRetCode/n1groupID/n1crc";
        $cmdArr = unpack($cmdFormat, $msgBin);
        $msgCRC = $cmdArr["crc"];
        return $cmdArr;
        
    }
    
}